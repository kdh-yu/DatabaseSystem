CREATE DATABASE Calendar;

-- Active: 1697603347199@@127.0.0.1@5432@calendar@public

CREATE SCHEMA calendar DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;